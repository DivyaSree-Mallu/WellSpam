export function LoadingState({ label = "Loading…" }) {
  return (
    <div className="state-box" role="status" aria-live="polite">
      <div className="icon" aria-hidden="true">⏳</div>
      {label}
    </div>
  );
}

export function EmptyState({ label = "Nothing to show here yet." }) {
  return (
    <div className="state-box">
      <div className="icon" aria-hidden="true">—</div>
      {label}
    </div>
  );
}

export function ErrorState({ label = "Could not load data. This is expected until a backend API is connected." }) {
  return (
    <div className="state-box error" role="alert">
      <div className="icon" aria-hidden="true">⚠</div>
      {label}
    </div>
  );
}
