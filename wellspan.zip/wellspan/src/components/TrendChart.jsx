import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

const COLORS = {
  heartRate: "#0E8478",
  spo2: "#2563A8",
  temperature: "#B7791F",
};

const LABELS = {
  heartRate: "Heart rate (BPM)",
  spo2: "SpO₂ (%)",
  temperature: "Temperature (°C)",
};

export default function TrendChart({ data, xKey = "time", series, height = 280 }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 12, left: -8, bottom: 0 }}>
        <CartesianGrid stroke="#E2ECEA" vertical={false} />
        <XAxis
          dataKey={xKey}
          tick={{ fontSize: 11, fill: "#5B6B69" }}
          tickLine={false}
          axisLine={{ stroke: "#D9E4E2" }}
        />
        <YAxis tick={{ fontSize: 11, fill: "#5B6B69" }} tickLine={false} axisLine={false} width={40} />
        <Tooltip
          contentStyle={{
            borderRadius: 6,
            border: "1px solid #D9E4E2",
            fontSize: 12,
            fontFamily: "IBM Plex Mono, monospace",
          }}
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {series.map((key) => (
          <Line
            key={key}
            type="monotone"
            dataKey={key}
            name={LABELS[key] || key}
            stroke={COLORS[key] || "#0E8478"}
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4 }}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}
