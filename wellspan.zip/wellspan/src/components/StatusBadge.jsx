const CONNECTION_LABELS = {
  connected: "Connected",
  interrupted: "Connection lost",
  not_configured: "No data",
};

const CONNECTION_CLASS = {
  connected: "badge-success",
  interrupted: "badge-critical",
  not_configured: "badge-offline",
};

const SEVERITY_CLASS = {
  info: "badge-info",
  warning: "badge-warning",
  critical: "badge-critical",
  success: "badge-success",
};

export function SeverityBadge({ severity, children }) {
  const cls = SEVERITY_CLASS[severity] || "badge-neutral";
  return (
    <span className={`badge ${cls}`}>
      {children || severity.charAt(0).toUpperCase() + severity.slice(1)}
    </span>
  );
}

export function ConnectionBadge({ state }) {
  const cls = CONNECTION_CLASS[state] || "badge-neutral";
  const label = CONNECTION_LABELS[state] || state;
  return <span className={`badge ${cls}`}>{label}</span>;
}

export default SeverityBadge;
