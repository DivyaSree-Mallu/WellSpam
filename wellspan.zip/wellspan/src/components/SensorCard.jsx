import { ConnectionBadge } from "./StatusBadge";

function formatTime(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function SensorCard({ sensor }) {
  const hasValue = sensor.value !== null && sensor.value !== undefined;
  return (
    <div className="sensor-card">
      <div className="head">
        <div>
          <div className="sensor-name">{sensor.name}</div>
          <div className="sensor-param">{sensor.parameter}</div>
        </div>
        <ConnectionBadge state={sensor.connection} />
      </div>

      <div className="sensor-value">
        {hasValue ? (
          <>
            {sensor.value}
            {sensor.unit ? <span className="unit">{sensor.unit}</span> : null}
          </>
        ) : (
          <span className="text-faint" style={{ fontSize: 14, fontFamily: "var(--font-ui)" }}>
            No data available
          </span>
        )}
      </div>

      <p className="small text-muted" style={{ margin: 0 }}>{sensor.note}</p>

      <div className="foot">
        <span>Source: {sensor.source}</span>
        <span>Updated: {formatTime(sensor.lastUpdated)}</span>
      </div>
    </div>
  );
}
