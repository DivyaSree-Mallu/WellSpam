import { NavLink } from "react-router-dom";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: "◉", end: true },
  { to: "/monitoring", label: "Sensor Monitoring", icon: "⌁" },
  { to: "/alerts", label: "Alerts & Safety", icon: "▲" },
  { to: "/history", label: "History & Analytics", icon: "◫" },
  { to: "/platform", label: "Platform Status", icon: "▭" },
  { to: "/model", label: "Predictive Insights", icon: "◈" },
  { to: "/about", label: "About", icon: "ℹ" },
];

export default function Sidebar({ open, onNavigate }) {
  return (
    <aside className={`sidebar ${open ? "open" : ""}`} aria-label="Primary navigation">
      <div className="sidebar-brand">
        <div className="sidebar-brand-mark" aria-hidden="true">🩺</div>
        <div className="sidebar-brand-text">
          <div className="name">Wellspan</div>
          <div className="tag">Patient Monitoring Platform</div>
        </div>
      </div>
      <nav className="sidebar-nav">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) => `sidebar-link ${isActive ? "active" : ""}`}
          >
            <span className="icon" aria-hidden="true">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-footer">
        <span className="hstack" style={{ gap: 6 }}>
          <span
            aria-hidden="true"
            style={{
              width: 7,
              height: 7,
              borderRadius: "50%",
              background: "#4ADE80",
              display: "inline-block",
            }}
          />
          System nominal
        </span>
        <div style={{ marginTop: 4, opacity: 0.8 }}>© 2026 Wellspan Health</div>
      </div>
    </aside>
  );
}
