export default function StatCard({ label, value, unit, status = "success", meta }) {
  return (
    <div className={`stat-card status-${status}`}>
      <span className="label">{label}</span>
      <span className="value">
        {value}
        {unit ? <span className="unit">{unit}</span> : null}
      </span>
      {meta ? <span className="meta">{meta}</span> : null}
    </div>
  );
}
