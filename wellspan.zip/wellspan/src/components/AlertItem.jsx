import { SeverityBadge } from "./StatusBadge";

function formatTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function AlertItem({ alert, onAcknowledge }) {
  const acknowledged = alert.status === "acknowledged";
  return (
    <div className={`alert-item sev-${alert.severity} ${acknowledged ? "acknowledged" : ""}`}>
      <span className="sev-dot" aria-hidden="true" />
      <div className="body">
        <div className="top-row">
          <span className="title">{alert.title}</span>
          <span className="time">{formatTime(alert.time)}</span>
        </div>
        <p className="desc">{alert.explanation}</p>
        <div className="tags">
          <SeverityBadge severity={alert.severity} />
          <span className="badge badge-neutral">{alert.sensor}</span>
        </div>
      </div>
      <button
        type="button"
        className="btn btn-sm btn-secondary"
        onClick={() => onAcknowledge(alert.id)}
        disabled={acknowledged}
        aria-label={acknowledged ? `${alert.title} already acknowledged` : `Acknowledge ${alert.title}`}
      >
        {acknowledged ? "Acknowledged" : "Acknowledge"}
      </button>
    </div>
  );
}
