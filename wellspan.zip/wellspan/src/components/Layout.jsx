import { useState } from "react";
import Sidebar from "./Sidebar";

export default function Layout({ children }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="app-shell">
      <div className="mobile-topbar">
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          aria-label="Open navigation menu"
        >
          ☰
        </button>
        <strong>Wellspan</strong>
        <span style={{ width: 34 }} />
      </div>

      <Sidebar open={mobileOpen} onNavigate={() => setMobileOpen(false)} />
      <div
        className={`sidebar-scrim ${mobileOpen ? "open" : ""}`}
        onClick={() => setMobileOpen(false)}
        aria-hidden="true"
      />

      <main className="main-content">{children}</main>
    </div>
  );
}
