export default function StatusBar({ text, tone = "info" }) {
  return (
    <div className="status-bar" role="status">
      <span aria-hidden="true">●</span>
      <span>{text}</span>
    </div>
  );
}
