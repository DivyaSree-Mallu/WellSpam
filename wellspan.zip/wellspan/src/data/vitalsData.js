// NOTE (developer-facing only): values below are static placeholder data.
// Swap fetchDashboardSummary() in src/services/api.js for a real API call
// once a live data source is connected — no UI changes needed.

export const dataSourceStatus = {
  connected: true,
  label: "All sensors reporting",
  lastSync: "2026-09-27T08:42:00",
};

export const vitalsSummary = [
  {
    id: "heartRate",
    label: "Heart Rate",
    value: 78,
    unit: "BPM",
    status: "success",
    meta: "Updated 08:42",
  },
  {
    id: "spo2",
    label: "SpO₂",
    value: 97,
    unit: "%",
    status: "success",
    meta: "Updated 08:42",
  },
  {
    id: "temperature",
    label: "Temperature",
    value: 36.8,
    unit: "°C",
    status: "success",
    meta: "Updated 08:41",
  },
  {
    id: "occupancy",
    label: "Occupancy",
    value: "Occupied",
    unit: "",
    status: "info",
    meta: "Updated 08:42",
  },
  {
    id: "battery",
    label: "Platform Battery",
    value: 68,
    unit: "%",
    status: "success",
    meta: "Updated 08:40",
  },
];

export const monitoringStatus = {
  state: "Monitoring active",
  description:
    "Wellspan is continuously tracking vitals and platform status across all connected sensors.",
};

export const recentAlertsPreview = [
  {
    id: "a1",
    severity: "warning",
    title: "Heart rate above configured threshold",
    time: "2026-09-27T08:15:00",
  },
  {
    id: "a2",
    severity: "info",
    title: "Sensor data refreshed",
    time: "2026-09-27T07:00:00",
  },
  {
    id: "a3",
    severity: "critical",
    title: "Pressure sensor connection interrupted",
    time: "2026-09-26T22:04:00",
  },
];

export const dashboardTrend = [
  { time: "06:00", heartRate: 66, spo2: 98, temperature: 36.5 },
  { time: "06:30", heartRate: 68, spo2: 98, temperature: 36.5 },
  { time: "07:00", heartRate: 71, spo2: 97, temperature: 36.6 },
  { time: "07:30", heartRate: 74, spo2: 97, temperature: 36.6 },
  { time: "08:00", heartRate: 79, spo2: 96, temperature: 36.7 },
  { time: "08:30", heartRate: 82, spo2: 97, temperature: 36.8 },
  { time: "08:42", heartRate: 78, spo2: 97, temperature: 36.8 },
];
