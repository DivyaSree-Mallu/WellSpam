// DEMO DATA ONLY — sample historical readings for the History & Analytics page.
// Generated deterministically (no Math.random) so the demo is reproducible.

function pad(n) {
  return String(n).padStart(2, "0");
}

// Generates a 24-hour sample series at a given interval, using smooth
// synthetic curves so charts look realistic without being random.
export function generateHistorySeries(hours = 24, stepMinutes = 30) {
  const points = [];
  const steps = Math.floor((hours * 60) / stepMinutes);
  const start = new Date("2026-09-25T09:00:00");

  for (let i = 0; i <= steps; i++) {
    const t = new Date(start.getTime() + i * stepMinutes * 60000);
    const hourFraction = t.getHours() + t.getMinutes() / 60;

    const heartRate = Math.round(
      72 + 8 * Math.sin((hourFraction / 24) * Math.PI * 2) + (i % 5)
    );
    const spo2 = Math.round(
      97 - Math.abs(Math.sin((hourFraction / 24) * Math.PI * 3)) * 2
    );
    const temperature = +(
      36.6 +
      0.3 * Math.sin((hourFraction / 24) * Math.PI * 2 + 1)
    ).toFixed(1);

    points.push({
      timestamp: `${pad(t.getMonth() + 1)}/${pad(t.getDate())} ${pad(
        t.getHours()
      )}:${pad(t.getMinutes())}`,
      isoTime: t.toISOString(),
      heartRate,
      spo2,
      temperature,
    });
  }
  return points;
}

export const fullHistory = generateHistorySeries(24, 30);

export function summarize(series, key) {
  if (!series.length) return { min: null, max: null, avg: null };
  const values = series.map((p) => p[key]);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const avg = +(values.reduce((a, b) => a + b, 0) / values.length).toFixed(1);
  return { min, max, avg };
}

export const rangeOptions = [
  { id: "6h", label: "Last 6 hours" },
  { id: "12h", label: "Last 12 hours" },
  { id: "24h", label: "Last 24 hours" },
];

export function filterByRange(series, rangeId) {
  const hoursMap = { "6h": 6, "12h": 12, "24h": 24 };
  const hours = hoursMap[rangeId] ?? 24;
  const pointsToKeep = Math.floor((hours * 60) / 30) + 1;
  return series.slice(-pointsToKeep);
}
