// NOTE (developer-facing only): values below are static placeholder data.
// Swap fetchPlatformStatus() in src/services/api.js for a real API call
// once platform telemetry is connected.

export const platformModes = [
  { id: "chair", label: "Chair Mode" },
  { id: "bed", label: "Bed Mode" },
];

export const platformSnapshot = {
  occupancy: "Occupied",
  orientation: "Upright, stable",
  movement: "No movement in last 2 minutes",
  battery: { percent: 68, voltage: "12.6 V", current: "0.8 A" },
};

export const connectionOverview = [
  { sensor: "MAX30102 (HR / SpO₂)", state: "connected" },
  { sensor: "Temperature sensor", state: "connected" },
  { sensor: "ECG electrodes", state: "connected" },
  { sensor: "Pressure sensor matrix", state: "interrupted" },
  { sensor: "Occupancy sensor", state: "connected" },
  { sensor: "MPU6050 IMU", state: "connected" },
  { sensor: "Wheel rotary encoder", state: "not_configured" },
  { sensor: "Current & voltage sensors", state: "connected" },
];
