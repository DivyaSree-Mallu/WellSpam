// NOTE (developer-facing only): values below are static placeholder data.
// Swap fetchAlerts()/acknowledgeAlert() in src/services/api.js for real
// backend calls once a live alerting pipeline is connected.

export const initialAlerts = [
  {
    id: "alert-001",
    severity: "warning",
    title: "Heart rate above configured threshold",
    sensor: "MAX30102 — Heart rate",
    time: "2026-09-27T08:15:00",
    explanation:
      "Heart rate crossed the configured warning threshold of 85 BPM at this timestamp.",
    status: "active",
  },
  {
    id: "alert-002",
    severity: "critical",
    title: "Pressure sensor connection interrupted",
    sensor: "Pressure sensor matrix",
    time: "2026-09-26T22:04:00",
    explanation:
      "The data feed for the pressure sensor matrix stopped updating for longer than the configured timeout.",
    status: "active",
  },
  {
    id: "alert-003",
    severity: "warning",
    title: "Stale sensor data detected",
    sensor: "Wheel rotary encoder",
    time: "2026-09-26T19:30:00",
    explanation:
      "No recent readings have been received from this sensor, so it is flagged as stale rather than showing an unverified value.",
    status: "active",
  },
  {
    id: "alert-004",
    severity: "info",
    title: "Sensor data refreshed",
    sensor: "All sensors",
    time: "2026-09-27T07:00:00",
    explanation: "Routine scheduled data refresh completed.",
    status: "acknowledged",
  },
  {
    id: "alert-005",
    severity: "warning",
    title: "SpO₂ dipped near threshold",
    sensor: "MAX30102 — SpO₂",
    time: "2026-09-26T14:12:00",
    explanation:
      "SpO₂ briefly approached the configured warning threshold of 94%.",
    status: "acknowledged",
  },
];
