import { useEffect, useState } from "react";
import StatusBar from "../components/StatusBar";
import SensorCard from "../components/SensorCard";
import { LoadingState, ErrorState } from "../components/StateBox";
import { fetchSensors } from "../services/api";

export default function Monitoring() {
  const [state, setState] = useState({ status: "loading", data: null });

  useEffect(() => {
    let cancelled = false;
    fetchSensors()
      .then((data) => !cancelled && setState({ status: "ready", data }))
      .catch(() => !cancelled && setState({ status: "error", data: null }));
    return () => { cancelled = true; };
  }, []);

  const activeCount = state.data ? state.data.filter((s) => s.connection === "connected").length : 0;

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Sensor Monitoring</h1>
          <p className="subtitle">
            Live readings across the full onboard sensor array.
          </p>
        </div>
      </div>

      <StatusBar text={state.data ? `${activeCount} of ${state.data.length} sensors connected` : "Checking sensor connections…"} />

      {state.status === "loading" && <LoadingState label="Loading sensors…" />}
      {state.status === "error" && <ErrorState />}

      {state.status === "ready" && (
        <div className="grid grid-sensors">
          {state.data.map((sensor) => (
            <SensorCard key={sensor.id} sensor={sensor} />
          ))}
        </div>
      )}
    </>
  );
}
