import { useEffect, useState } from "react";
import StatusBar from "../components/StatusBar";
import { ConnectionBadge } from "../components/StatusBadge";
import { LoadingState, ErrorState } from "../components/StateBox";
import { fetchPlatformStatus } from "../services/api";
import { platformModes } from "../data/platformData";

export default function PlatformStatus() {
  const [state, setState] = useState({ status: "loading", data: null });
  const [mode, setMode] = useState("chair");

  useEffect(() => {
    let cancelled = false;
    fetchPlatformStatus()
      .then((data) => !cancelled && setState({ status: "ready", data }))
      .catch(() => !cancelled && setState({ status: "error", data: null }));
    return () => { cancelled = true; };
  }, []);

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Platform Status</h1>
          <p className="subtitle">
            Live position, occupancy, and electrical status of the assistive platform.
          </p>
        </div>
      </div>

      <StatusBar text="Platform telemetry connected" />

      {state.status === "loading" && <LoadingState label="Loading platform status…" />}
      {state.status === "error" && <ErrorState />}

      {state.status === "ready" && (
        <div className="stack">
          <div className="card">
            <div className="card-title-row"><h3>Operating mode</h3></div>
            <div className="segmented" role="group" aria-label="Operating mode">
              {platformModes.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  className={mode === m.id ? "active" : ""}
                  onClick={() => setMode(m.id)}
                  aria-pressed={mode === m.id}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-2">
            <div className="card">
              <div className="card-title-row"><h3>Occupancy &amp; movement</h3></div>
              <div className="stack" style={{ gap: 10, fontSize: 14 }}>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span className="text-muted">Occupancy</span>
                  <strong>{state.data.platformSnapshot.occupancy}</strong>
                </div>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span className="text-muted">Orientation</span>
                  <strong>{state.data.platformSnapshot.orientation}</strong>
                </div>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span className="text-muted">Movement</span>
                  <strong>{state.data.platformSnapshot.movement}</strong>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-title-row"><h3>Electrical / battery status</h3></div>
              <div className="stack" style={{ gap: 10, fontSize: 14 }}>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span className="text-muted">Battery</span>
                  <strong className="mono">{state.data.platformSnapshot.battery.percent}%</strong>
                </div>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span className="text-muted">Voltage</span>
                  <strong className="mono">{state.data.platformSnapshot.battery.voltage}</strong>
                </div>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span className="text-muted">Current</span>
                  <strong className="mono">{state.data.platformSnapshot.battery.current}</strong>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-title-row"><h3>Sensor connection overview</h3></div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Sensor</th><th>Connection state</th></tr>
                </thead>
                <tbody>
                  {state.data.connectionOverview.map((row) => (
                    <tr key={row.sensor}>
                      <td>{row.sensor}</td>
                      <td><ConnectionBadge state={row.state} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
