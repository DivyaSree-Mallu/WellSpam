export default function About() {
  return (
    <>
      <div className="page-header">
        <div>
          <h1>About Wellspan</h1>
          <p className="subtitle">Real-time, multi-sensor health monitoring and patient safety.</p>
        </div>
      </div>

      <div className="stack">
        <div className="card">
          <h3 style={{ marginBottom: 10 }}>What Wellspan does</h3>
          <p style={{ fontSize: 14, color: "var(--text-muted)", lineHeight: 1.7 }}>
            Wellspan continuously monitors vitals — heart rate, SpO₂, temperature — alongside
            platform status such as occupancy, orientation, and electrical health. It surfaces
            anomalies as alerts and keeps a searchable history so patterns are easy to review
            over time.
          </p>
        </div>

        <div className="card">
          <h3 style={{ marginBottom: 10 }}>How it works</h3>
          <p style={{ fontSize: 14, color: "var(--text-muted)", lineHeight: 1.7 }}>
            An onboard sensor array streams readings to the dashboard, where configurable
            thresholds trigger alerts and a predictive model surfaces early-warning patterns as
            it becomes available. Every screen distinguishes what's actively connected from what
            still needs attention, so nothing is presented as certain when it isn't.
          </p>
        </div>

        <div className="card">
          <h3 style={{ marginBottom: 10 }}>Important note</h3>
          <p style={{ fontSize: 14, color: "var(--text-muted)", lineHeight: 1.7 }}>
            Wellspan is a monitoring and alerting tool. It does not diagnose medical conditions
            and is not a substitute for professional medical care. Always consult a qualified
            clinician for medical decisions.
          </p>
        </div>
      </div>
    </>
  );
}
