import { useEffect, useState } from "react";
import StatusBar from "../components/StatusBar";
import { LoadingState, ErrorState } from "../components/StateBox";
import { fetchModelAnalysis } from "../services/api";

export default function ModelAnalysis() {
  const [state, setState] = useState({ status: "loading", data: null });

  useEffect(() => {
    let cancelled = false;
    fetchModelAnalysis()
      .then((data) => !cancelled && setState({ status: "ready", data }))
      .catch(() => !cancelled && setState({ status: "error", data: null }));
    return () => { cancelled = true; };
  }, []);

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Predictive Insights</h1>
          <p className="subtitle">
            Pattern detection and early-warning insights derived from sensor history.
          </p>
        </div>
      </div>

      <StatusBar text="Predictive model: calibration in progress" />

      {state.status === "loading" && <LoadingState label="Checking model status…" />}
      {state.status === "error" && <ErrorState />}

      {state.status === "ready" && !state.data.connected && (
        <div className="card">
          <div className="card-title-row">
            <h3>Model status</h3>
            <span className="badge badge-warning">Calibrating</span>
          </div>
          <p style={{ fontSize: 14, color: "var(--text-muted)", marginBottom: 20 }}>
            Predictive insights will appear here once the model has enough sensor history to
            produce a calibrated result. No prediction is shown until then.
          </p>

          <div className="table-wrap">
            <table>
              <tbody>
                <tr><td style={{ fontWeight: 700 }}>Predicted class</td><td>Awaiting calibration</td></tr>
                <tr><td style={{ fontWeight: 700 }}>Confidence / probability</td><td>Awaiting calibration</td></tr>
                <tr><td style={{ fontWeight: 700 }}>Explanation of detected pattern</td><td>Awaiting calibration</td></tr>
                <tr><td style={{ fontWeight: 700 }}>Model version</td><td>Awaiting calibration</td></tr>
                <tr><td style={{ fontWeight: 700 }}>Data timestamp</td><td>Awaiting calibration</td></tr>
              </tbody>
            </table>
          </div>

          <p className="small text-faint" style={{ marginTop: 16 }}>
            Predictive insights are experimental and are never a substitute for professional
            medical assessment.
          </p>
        </div>
      )}
    </>
  );
}
