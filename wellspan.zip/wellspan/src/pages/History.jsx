import { useEffect, useMemo, useState } from "react";
import StatusBar from "../components/StatusBar";
import TrendChart from "../components/TrendChart";
import { LoadingState, ErrorState } from "../components/StateBox";
import { fetchHistory } from "../services/api";
import { rangeOptions, filterByRange, summarize } from "../data/historyData";

const SERIES_META = [
  { key: "heartRate", label: "Heart rate", unit: "BPM" },
  { key: "spo2", label: "SpO₂", unit: "%" },
  { key: "temperature", label: "Temperature", unit: "°C" },
];

export default function History() {
  const [state, setState] = useState({ status: "loading", data: [] });
  const [range, setRange] = useState("12h");

  useEffect(() => {
    let cancelled = false;
    fetchHistory()
      .then((data) => !cancelled && setState({ status: "ready", data }))
      .catch(() => !cancelled && setState({ status: "error", data: [] }));
    return () => { cancelled = true; };
  }, []);

  const filtered = useMemo(
    () => filterByRange(state.data, range),
    [state.data, range]
  );

  return (
    <>
      <div className="page-header">
        <div>
          <h1>History &amp; Analytics</h1>
          <p className="subtitle">
            Historical readings, trends, and summary statistics across your selected time range.
          </p>
        </div>
      </div>

      <StatusBar text="Historical data connected" />

      {state.status === "loading" && <LoadingState label="Loading history…" />}
      {state.status === "error" && <ErrorState />}

      {state.status === "ready" && (
        <div className="stack">
          <div className="card">
            <div className="field-row">
              <div>
                <span className="field-label">Time range</span>
                <select value={range} onChange={(e) => setRange(e.target.value)} aria-label="Select time range">
                  {rangeOptions.map((r) => (
                    <option key={r.id} value={r.id}>{r.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-stats">
            {SERIES_META.map((s) => {
              const sum = summarize(filtered, s.key);
              return (
                <div className="stat-card" key={s.key}>
                  <span className="label">{s.label} — min / avg / max</span>
                  <span className="value" style={{ fontSize: 18 }}>
                    {sum.min} / {sum.avg} / {sum.max}
                    <span className="unit">{s.unit}</span>
                  </span>
                  <span className="meta">Selected range</span>
                </div>
              );
            })}
          </div>

          <div className="card">
            <div className="card-title-row"><h3>Heart rate &amp; SpO₂ trend</h3></div>
            <TrendChart data={filtered} xKey="timestamp" series={["heartRate", "spo2"]} height={280} />
          </div>

          <div className="card">
            <div className="card-title-row"><h3>Temperature trend</h3></div>
            <TrendChart data={filtered} xKey="timestamp" series={["temperature"]} height={220} />
          </div>

          <div className="card">
            <div className="card-title-row"><h3>Readings table</h3></div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Timestamp</th>
                    <th>Heart rate (BPM)</th>
                    <th>SpO₂ (%)</th>
                    <th>Temperature (°C)</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((row) => (
                    <tr key={row.isoTime}>
                      <td className="num">{row.timestamp}</td>
                      <td className="num">{row.heartRate}</td>
                      <td className="num">{row.spo2}</td>
                      <td className="num">{row.temperature}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
