import { useEffect, useState } from "react";
import StatusBar from "../components/StatusBar";
import AlertItem from "../components/AlertItem";
import { LoadingState, ErrorState, EmptyState } from "../components/StateBox";
import { fetchAlerts, acknowledgeAlert } from "../services/api";

export default function Alerts() {
  const [state, setState] = useState({ status: "loading", data: [] });

  useEffect(() => {
    let cancelled = false;
    fetchAlerts()
      .then((data) => !cancelled && setState({ status: "ready", data }))
      .catch(() => !cancelled && setState({ status: "error", data: [] }));
    return () => { cancelled = true; };
  }, []);

  async function handleAcknowledge(id) {
    setState((s) => ({
      ...s,
      data: s.data.map((a) => (a.id === id ? { ...a, status: "acknowledged" } : a)),
    }));
    try {
      await acknowledgeAlert(id);
    } catch {
      // In a full implementation we would roll back optimistic state and
      // surface an error toast here once a real backend is connected.
    }
  }

  const active = state.data.filter((a) => a.status === "active");
  const previous = state.data.filter((a) => a.status === "acknowledged");

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Alerts &amp; Safety Events</h1>
          <p className="subtitle">
            Active and past safety alerts across all monitored sensors. Wellspan surfaces
            anomalies for review — it does not diagnose conditions or replace professional
            medical assessment.
          </p>
        </div>
      </div>

      <StatusBar text="Alert pipeline connected" />

      {state.status === "loading" && <LoadingState label="Loading alerts…" />}
      {state.status === "error" && <ErrorState />}

      {state.status === "ready" && (
        <div className="stack" style={{ gap: 32 }}>
          <section>
            <h3 style={{ fontSize: 15, marginBottom: 12 }}>Active alerts ({active.length})</h3>
            {active.length === 0 ? (
              <EmptyState label="No active alerts." />
            ) : (
              <div className="stack" style={{ gap: 10 }}>
                {active.map((a) => (
                  <AlertItem key={a.id} alert={a} onAcknowledge={handleAcknowledge} />
                ))}
              </div>
            )}
          </section>

          <section>
            <h3 style={{ fontSize: 15, marginBottom: 12 }}>Previous alerts ({previous.length})</h3>
            {previous.length === 0 ? (
              <EmptyState label="No acknowledged alerts yet." />
            ) : (
              <div className="stack" style={{ gap: 10 }}>
                {previous.map((a) => (
                  <AlertItem key={a.id} alert={a} onAcknowledge={handleAcknowledge} />
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </>
  );
}
