import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import StatusBar from "../components/StatusBar";
import StatCard from "../components/StatCard";
import { SeverityBadge } from "../components/StatusBadge";
import TrendChart from "../components/TrendChart";
import { LoadingState, ErrorState } from "../components/StateBox";
import { fetchDashboardSummary } from "../services/api";

function formatTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function Dashboard() {
  const [state, setState] = useState({ status: "loading", data: null });

  useEffect(() => {
    let cancelled = false;
    fetchDashboardSummary()
      .then((data) => !cancelled && setState({ status: "ready", data }))
      .catch(() => !cancelled && setState({ status: "error", data: null }));
    return () => { cancelled = true; };
  }, []);

  return (
    <>
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p className="subtitle">
            Real-time multi-sensor health monitoring and patient safety overview.
          </p>
        </div>
      </div>

      <StatusBar text={`All sensors reporting. Last updated ${state.data ? formatTime(state.data.dataSourceStatus.lastSync) : "—"}.`} />

      {state.status === "loading" && <LoadingState label="Loading dashboard…" />}
      {state.status === "error" && <ErrorState />}

      {state.status === "ready" && (
        <div className="stack">
          <div className="card">
            <div className="card-title-row">
              <h3>Monitoring status</h3>
              <SeverityBadge severity="success">Active</SeverityBadge>
            </div>
            <p className="text-muted" style={{ fontSize: 14 }}>
              {state.data.monitoringStatus.description}
            </p>
          </div>

          <div>
            <div className="card-title-row" style={{ marginBottom: 12 }}>
              <h3 style={{ fontSize: 15 }}>Current readings</h3>
            </div>
            <div className="grid grid-stats">
              {state.data.vitalsSummary.map((v) => (
                <Link
                  key={v.id}
                  to="/monitoring"
                  style={{ textDecoration: "none", color: "inherit" }}
                  aria-label={`${v.label}: ${v.value}${v.unit}. View sensor details.`}
                >
                  <StatCard {...v} />
                </Link>
              ))}
            </div>
          </div>

          <div className="grid grid-2">
            <div className="card">
              <div className="card-title-row">
                <h3>Recent trend</h3>
              </div>
              <TrendChart
                data={state.data.dashboardTrend}
                series={["heartRate", "spo2"]}
                height={240}
              />
            </div>

            <div className="card">
              <div className="card-title-row">
                <h3>Recent alerts</h3>
                <Link to="/alerts" className="small">View all →</Link>
              </div>
              <div className="stack" style={{ gap: 10 }}>
                {state.data.recentAlertsPreview.map((a) => (
                  <div key={a.id} className="hstack" style={{ justifyContent: "space-between", fontSize: 13.5 }}>
                    <span className="hstack" style={{ gap: 8 }}>
                      <SeverityBadge severity={a.severity} />
                      <span>{a.title}</span>
                    </span>
                    <span className="text-faint small mono">{formatTime(a.time)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
