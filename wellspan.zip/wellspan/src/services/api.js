// ---------------------------------------------------------------------------
// Service / API layer (developer-facing notes).
//
// Every function here currently returns static placeholder data shaped the
// way the future Python (Flask/FastAPI) backend is expected to respond.
// When the real backend and sensors are ready, replace the body of each
// function with an actual `fetch(...)` call — the pages that consume these
// functions should not need to change.
// ---------------------------------------------------------------------------

import {
  dataSourceStatus,
  vitalsSummary,
  monitoringStatus,
  recentAlertsPreview,
  dashboardTrend,
} from "../data/vitalsData";
import { sensors } from "../data/sensorsData";
import { initialAlerts } from "../data/alertsData";
import { fullHistory } from "../data/historyData";
import { platformSnapshot, connectionOverview } from "../data/platformData";

const SIMULATED_LATENCY_MS = 250;

function mockResolve(payload) {
  return new Promise((resolve) => {
    setTimeout(() => resolve(payload), SIMULATED_LATENCY_MS);
  });
}

// -------------------- Dashboard --------------------
export async function fetchDashboardSummary() {
  return mockResolve({
    dataSourceStatus,
    vitalsSummary,
    monitoringStatus,
    recentAlertsPreview,
    dashboardTrend,
  });
}

// -------------------- Sensors --------------------
export async function fetchSensors() {
  return mockResolve(sensors);
}

// -------------------- Alerts --------------------
export async function fetchAlerts() {
  return mockResolve(initialAlerts);
}

// In the real system this would PATCH /api/alerts/:id on the backend.
export async function acknowledgeAlert(alertId) {
  return mockResolve({ id: alertId, status: "acknowledged" });
}

// -------------------- History / analytics --------------------
export async function fetchHistory() {
  return mockResolve(fullHistory);
}

// -------------------- Platform status --------------------
export async function fetchPlatformStatus() {
  return mockResolve({ platformSnapshot, connectionOverview });
}

// -------------------- Model analysis (placeholder) --------------------
// The ML model is still being trained/calibrated. This function intentionally
// returns a "not yet available" response rather than a fabricated prediction.
export async function fetchModelAnalysis() {
  return mockResolve({
    connected: false,
    message: "Predictive insights are not available yet — model calibration is in progress.",
    predictedClass: null,
    confidence: null,
    explanation: null,
    modelVersion: null,
    dataTimestamp: null,
  });
}
